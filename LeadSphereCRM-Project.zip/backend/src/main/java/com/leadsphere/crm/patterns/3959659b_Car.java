package com.leadsphere.crm.patterns;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@DiscriminatorValue(value = "CAR")
public class Car extends PassengerVehicle {

  private int engineCapacity;

  public Car(String manufacturer, String model, int noOfPassengers, int engineCapacity) {
    super(manufacturer, model, noOfPassengers);
    this.engineCapacity = engineCapacity;
  }

  // Overridden the toString method to specify the Vehicle object
  @Override
  public String toString() {
    return "Car{" + super.toString() + '}';
  }
}
