package com.leadsphere.crm.patterns;

public interface Weapon {

  void wield();

  void swing();

  void unwield();

  Enchantment getEnchantment();
}
