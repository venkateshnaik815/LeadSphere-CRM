import zipfile
import os

source = r'c:\Users\VENKATESH NAIK\OneDrive\Documents\Desktop\LeadSphere CRM'
dest = r'c:\Users\VENKATESH NAIK\OneDrive\Documents\Desktop\LeadSphereCRM.zip'

def should_exclude(path):
    parts = path.split(os.sep)
    return any(p in ['node_modules', 'target', 'dist', 'build'] for p in parts) or path.endswith('LeadSphereCRM-Project.zip')

with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(source):
        # Exclude directories in-place so os.walk doesn't traverse them
        dirs[:] = [d for d in dirs if not should_exclude(os.path.join(root, d))]
        
        for file in files:
            file_path = os.path.join(root, file)
            if not should_exclude(file_path):
                arcname = os.path.relpath(file_path, source)
                zipf.write(file_path, arcname)

print('Zip created at ' + dest)
